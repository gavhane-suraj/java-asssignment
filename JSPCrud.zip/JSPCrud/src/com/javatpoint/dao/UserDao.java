package com.javatpoint.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.javatpoint.bean.User;

public class UserDao {

    public static Connection getConnection() {
        Connection con = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/assignment", "root", "root");
        } catch (Exception e) {
            System.out.println(e);
        }
        return con;
    }

    public static boolean login(String email, String pass) {
        try {
            Connection con = getConnection();
            String sqlSelect = "SELECT * FROM users WHERE email=? AND password=?";
            PreparedStatement ps = con.prepareStatement(sqlSelect);
            ps.setString(1, email);
            ps.setString(2, pass);
            ResultSet rs = ps.executeQuery();
            while (rs.getRow() > 0) {
                return true;
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        
        return false;
    }

}
