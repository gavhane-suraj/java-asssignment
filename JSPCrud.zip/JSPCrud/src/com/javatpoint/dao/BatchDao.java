package com.javatpoint.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.javatpoint.bean.Batch;

public class BatchDao {

    public static Connection getConnection() {
        Connection con = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/assignment", "root", "root");
        } catch (Exception e) {
            System.out.println(e);
        }
        return con;
    }

    public static List searchByQualityId(String qualityId) {
        List list = new ArrayList();
        try {
            Connection con = getConnection();
            String sqlSelect = "SELECT batch_id,SUM(meter) as sum_meter "
                    + "FROM batches "
                    + "JOIN stocks ON stocks.stock_id = batches.stock_id "
                    + "JOIN quality ON quality.quality_id = stocks.quality_id"
                    + "WHERE quality.quality_id = " + qualityId +" "
                    + "GROUP BY batches.batch_id";
            PreparedStatement ps = con.prepareStatement(sqlSelect);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Batch b = new Batch();
                b.setId(rs.getInt("id"));
                b.setSum(rs.getInt("sum_meter"));
                list.add(b);
            }
        } catch (Exception e) {
            System.out.println(e);
        }

        return list;
    }
}
